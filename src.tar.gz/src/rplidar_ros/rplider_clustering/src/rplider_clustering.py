#!/usr/bin/env python
import rospy
import tf
from geometry_msgs.msg import PointStamped, Marker, Point
from sensor_msgs.msg import PointCloud2
from sklearn.cluster import DBSCAN
import numpy as np

class RplidarClustering:
    def __init__(self):
        self.points = []
        self.dbscan = DBSCAN(eps=0.1, min_samples=5)
        self.marker_publisher = rospy.Publisher('/rplidar/clusters', MarkerArray, queue_size=10)
        self.pc2_subscriber = rospy.Subscriber('/rplidar/points', PointCloud2, self.callback)
        self.tfBuffer = tf.TransformBuffer()

    def callback(self, data):
        cloud = np.asarray(data.fields, order='F')
        points = np.asarray(cloud[0])
        self.points += list(points)

        if len(self.points) > 10:
            clustered_points = self.dbscan.fit_predict(np.vstack((np.ones((len(self.points), 1)).astype('float32'), np.asarray(self.points))).T)
            markers = self.process_clusters(clustered_points)
            self.marker_publisher.publish(markers)
            self.points = []

    def process_clusters(self, clusters):
        markers = MarkerArray()
        for i in range(np.max(clusters)+1):
            if np.count_nonzero(clusters == i) > 0:
                centroid = np.mean(np.asarray(self.points)[np.where(clusters == i)], axis=0)
                position = PointStamped()
                position.point = centroid
                marker = self.create_marker(position, i)
                markers.markers.append(marker)
        return markers

    def create_marker(self, position, id):
        marker = Marker()
        marker.header.frame_id = 'map'
        marker.header.stamp = rospy.Time.now()
        marker.ns = 'rplidar_clustering'
        marker.id = id
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.scale.x = 0.1
        marker.scale.y = 0.1
        marker.scale.z = 0.1
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        self.tfBuffer.transform(rospy.Time(), 'map', position.header, position)
        marker.position = position.points[0]
        return marker

if __name__ == '__main__':
    rospy.init_node('rplidar_clustering')
    node = RplidarClustering()
    rospy.spin(node)