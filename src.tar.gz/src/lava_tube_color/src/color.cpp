#include <opencv2/opencv.hpp>
#include <sl/Camera.hpp>
#include <iostream>

using namespace sl;
using namespace std;

int main(){
    //zed cam related code:
    //Creating camera object
    Camera zed;
    //setting up camera configuration
    InitParameters init_params;
    init_params.sdk_verbose = 1;
    init_params.depth_mode = DEPTH_MODE::ULTRA;
    init_params.camera_resolution = RESOLUTION::HD1080;
    init_params.coordinate_units = UNIT::METER;
    init_params.sensors_required = false;
    //init_params.camera_fps = 60;

    //opening the camera
    ERROR_CODE err = zed.open(init_params);
    if(err!= ERROR_CODE::SUCCESS){
        cout << "Camera open failed: " << toString(err) << "\n";
        return 1;
    }

    //creating opencv window.
    //this is just for debugging and testing
    //cv::namedWindow("Color detection", cv::WINDOW_NORMAL);

    //timer for calculating frame rate
    auto start_time = chrono::high_resolution_clock::now();
    int frame_count = 0;
    int print_interval = 30; // Interval in frames to print the FPS

    while(true){
        //grabing a frame form camera
        if (zed.grab() != ERROR_CODE::SUCCESS){
            cout << "Failed to capture frame\n";
            return 1;
        }

        //palce holder to keep the frame and depth
        Mat right_frame, left_frame, depth, point_cloud;
        //getting right frame
        //zed.retrieveImage(right_frame, VIEW::RIGHT);
        //getting left frame
        zed.retrieveImage(left_frame, VIEW::LEFT);
        // Retrieve depth Mat. Depth is aligned on the left frame
        zed.retrieveMeasure(depth, MEASURE::DEPTH);
        zed.retrieveMeasure(point_cloud, MEASURE::XYZRGBA);


        //Converting ZED image to OpenCV formate
        //cv::Mat right_cv_image = cv::Mat(right_frame.getHeight(), right_frame.getWidth(), CV_8UC4, right_frame.getPtr<sl::uchar1>(sl::MEM::CPU));
        cv::Mat left_cv_image = cv::Mat(left_frame.getHeight(), left_frame.getWidth(), CV_8UC4, left_frame.getPtr<sl::uchar1>(sl::MEM::CPU));

        //converting the right_frame and left_frame to HSV color space
         cv::Mat right_hsv_image, left_hsv_image;
        // cv::cvtColor(right_cv_image, right_hsv_image, cv::COLOR_BGR2HSV);
         cv::cvtColor(left_cv_image, left_hsv_image, cv::COLOR_BGR2HSV);

        //difinging the range of the red color
        cv::Scalar lower_red = cv::Scalar(0, 100, 100);
        cv::Scalar upper_red = cv::Scalar(10, 255, 255);

        
        // Threshold the HSV image to get only red color
        cv::Mat left_mask;
        //cv::Mat right_mask;
        cv::inRange(left_hsv_image, lower_red, upper_red, left_mask);
        //cv::inRange(right_hsv_image, lower_red, upper_red, right_mask);

        // Find contours in the masks
        vector<vector<cv::Point>> left_contours, right_contours;
        vector<cv::Vec4i> left_hierarchy, right_hierarchy;
        cv::findContours(left_mask, left_contours, left_hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);
        //cv::findContours(right_mask, right_contours, right_hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);

        // Find the largest contour and draw a bounding box around it
        //left frame
        if (!left_contours.empty()) {
            double max_area = 0;
            int max_area_index = -1;
            for (size_t i = 0; i < left_contours.size(); i++) {
                double area = cv::contourArea(left_contours[i]);
                if (area > max_area) {
                    max_area = area;
                    max_area_index = i;
                }
            }
            if (max_area_index >= 0) {
                cv::Rect left_bounding_rect = cv::boundingRect(left_contours[max_area_index]);
                cv::rectangle(left_cv_image, left_bounding_rect, cv::Scalar(0, 255, 0), 2);

                //calculating the center of bounding box
                cv::Point left_center = (left_bounding_rect.tl() + left_bounding_rect.br()) / 2;
                sl::float4 point_cloud_value;
                point_cloud.getValue(left_center.x, left_center.y, &point_cloud_value);

                if(std::isfinite(point_cloud_value.z)){
                    float distance = sqrt(point_cloud_value.x * point_cloud_value.x + point_cloud_value.y * point_cloud_value.y + point_cloud_value.z * point_cloud_value.z);
                    cout<<distance<<" m"<<endl;
                }else{
                    cout<<"The Distance can not be computed\n";
                }
            }
        }

        //right frame

        // if (!right_contours.empty()) {
        //     double max_area = 0;
        //     int max_area_index = -1;
        //     for (size_t i = 0; i < right_contours.size(); i++) {
        //         double area = cv::contourArea(right_contours[i]);
        //         if (area > max_area) {
        //             max_area = area;
        //             max_area_index = i;
        //         }
        //     }
        //     if (max_area_index >= 0) {
        //         cv::Rect right_bounding_rect = cv::boundingRect(right_contours[max_area_index]);
        //         cv::rectangle(right_cv_image, right_bounding_rect, cv::Scalar(0, 255, 0), 2);
        //     }
        // }

        // Display the masked image
        cv::imshow("left_Masked Image", left_cv_image);
        //cv::imshow("right_Masked Image", right_cv_image);

        //wait for key press
        if(cv::waitKey(1) == 27){
            break;
        }


        //Calculate and print FPS every print_interval frames
        frame_count++;
        if (frame_count % print_interval == 0) {
            auto end_time = chrono::high_resolution_clock::now();
            auto duration = chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count();
            double fps = (frame_count / (duration / 1000.0));
            cout << "FPS: " << fps << endl;
        }
    }




    //closing the camera
    zed.close();
    return 0;
}
